import { UserRole } from './types';

export const APP_NAME = "Studio";
export const INVITE_CODE = "STUDIO2024"; // Código secreto para cadastro atualizado

export const DAYS_OF_WEEK = ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo'];

export const MOCK_USER_ADMIN = {
  id: 'admin-1',
  name: 'Treinador Alex',
  email: 'admin@studio.com',
  role: UserRole.ADMIN,
  avatarUrl: 'https://ui-avatars.com/api/?name=Treinador+Alex&background=f97316&color=fff',
  joinDate: '2023-01-01',
  phoneNumber: '5511999999999',
  address: 'Rua do Studio, 100 - Centro, SP'
};

export const MOCK_USER_STUDENT = {
  id: 'student-1',
  name: 'Mariana Costa',
  email: 'mariana@example.com',
  role: UserRole.STUDENT,
  avatarUrl: 'https://ui-avatars.com/api/?name=Mariana+Costa&background=random',
  joinDate: '2023-06-15',
  phoneNumber: '5511988888888',
  address: 'Av. Paulista, 1500 - Ap 42 - Bela Vista, São Paulo - SP'
};

export const WORKOUT_TYPES = ['FUNCIONAL', 'CORRIDA', 'FORÇA', 'MOBILIDADE'];