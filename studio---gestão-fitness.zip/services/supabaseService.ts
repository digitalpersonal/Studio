
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { User, ClassSession, Assessment, Post, Payment, Route, PersonalizedWorkout, Anamnesis } from '../types';

// Credenciais fornecidas pelo usuário
const SUPABASE_URL = process.env.SUPABASE_URL || 'https://xdjrrxrepnnkvpdbbtot.supabase.co';
const SUPABASE_ANON_KEY = process.env.SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhkanJyeHJlcG5ua3ZwZGJidG90Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjYzMjM3NzgsImV4cCI6MjA4MTg5OTc3OH0.6M4HQAVS0Z6cdvwMJCeOSvCKBkozHwQz3X9tgaZojEk';

// Inicialização segura do cliente
let supabase: SupabaseClient | null = null;
if (SUPABASE_URL && SUPABASE_URL.startsWith('http')) {
  supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
}

const isConfigured = () => {
  if (!supabase) {
    console.warn("Supabase não configurado corretamente. Verifique a URL e a Chave Anon.");
    return false;
  }
  return true;
};

export const SupabaseService = {
  // --- USUÁRIOS ---
  getAllStudents: async (): Promise<User[]> => {
    if (!isConfigured()) return [];
    const { data, error } = await supabase!
      .from('users')
      .select('*')
      .eq('role', 'STUDENT')
      .order('name');
    if (error) throw error;
    return data as User[];
  },

  addStudent: async (student: Omit<User, 'id'>): Promise<User> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('users')
      .insert([student])
      .select()
      .single();
    if (error) throw error;
    return data as User;
  },

  updateStudent: async (updatedStudent: User): Promise<User> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('users')
      .update(updatedStudent)
      .eq('id', updatedStudent.id)
      .select()
      .single();
    if (error) throw error;
    return data as User;
  },

  deleteStudent: async (id: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!.from('users').delete().eq('id', id);
    if (error) throw error;
    return true;
  },

  saveAnamnesis: async (userId: string, anamnesis: Anamnesis): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!
      .from('users')
      .update({ anamnesis })
      .eq('id', userId);
    if (error) throw error;
    return true;
  },

  // --- AULAS ---
  getClasses: async (): Promise<ClassSession[]> => {
    if (!isConfigured()) return [];
    const { data, error } = await supabase!
      .from('classes')
      .select('*')
      .order('start_time');
    if (error) throw error;
    return data as ClassSession[];
  },

  addClass: async (newClass: Omit<ClassSession, 'id'>): Promise<ClassSession> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('classes')
      .insert([newClass])
      .select()
      .single();
    if (error) throw error;
    return data as ClassSession;
  },

  enrollStudent: async (classId: string, studentId: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { data: cls, error: fetchError } = await supabase!
      .from('classes')
      .select('enrolled_student_ids, max_capacity')
      .eq('id', classId)
      .single();
    
    if (fetchError) throw fetchError;

    if (cls && cls.enrolled_student_ids.length < cls.max_capacity) {
      if (cls.enrolled_student_ids.includes(studentId)) return true;
      const updatedIds = [...cls.enrolled_student_ids, studentId];
      const { error: updateError } = await supabase!
        .from('classes')
        .update({ enrolled_student_ids: updatedIds })
        .eq('id', classId);
      if (updateError) throw updateError;
      return true;
    }
    return false;
  },

  // --- FREQUÊNCIA ---
  saveAttendance: async (classId: string, presentStudentIds: string[]): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!
      .from('attendance')
      .upsert({ 
        class_id: classId, 
        present_student_ids: presentStudentIds,
        attendance_date: new Date().toISOString().split('T')[0] 
      }, { onConflict: 'class_id,attendance_date' });
    if (error) throw error;
    return true;
  },

  getClassAttendance: async (classId: string): Promise<string[]> => {
    if (!isConfigured()) return [];
    const { data, error } = await supabase!
      .from('attendance')
      .select('present_student_ids')
      .eq('class_id', classId)
      .eq('attendance_date', new Date().toISOString().split('T')[0])
      .single();
    if (error && error.code !== 'PGRST116') throw error;
    return data?.present_student_ids || [];
  },

  hasAttendance: async (classId: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { data } = await supabase!
      .from('attendance')
      .select('id')
      .eq('class_id', classId)
      .eq('attendance_date', new Date().toISOString().split('T')[0]);
    return !!data && data.length > 0;
  },

  // --- AVALIAÇÕES ---
  getAssessments: async (studentId?: string): Promise<Assessment[]> => {
    if (!isConfigured()) return [];
    let query = supabase!.from('assessments').select('*').order('date', { ascending: false });
    if (studentId) query = query.eq('student_id', studentId);
    const { data, error } = await query;
    if (error) throw error;
    return data as Assessment[];
  },

  addAssessment: async (newAssessment: Omit<Assessment, 'id'>): Promise<Assessment> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('assessments')
      .insert([newAssessment])
      .select()
      .single();
    if (error) throw error;
    return data as Assessment;
  },

  updateAssessment: async (updatedAssessment: Assessment): Promise<Assessment> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('assessments')
      .update(updatedAssessment)
      .eq('id', updatedAssessment.id)
      .select()
      .single();
    if (error) throw error;
    return data as Assessment;
  },

  deleteAssessment: async (id: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!.from('assessments').delete().eq('id', id);
    if (error) throw error;
    return true;
  },

  // --- PAGAMENTOS ---
  getPayments: async (studentId?: string): Promise<Payment[]> => {
    if (!isConfigured()) return [];
    let query = supabase!.from('payments').select('*').order('due_date');
    if (studentId) query = query.eq('student_id', studentId);
    const { data, error } = await query;
    if (error) throw error;
    return data as Payment[];
  },

  markPaymentAsPaid: async (id: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!.from('payments').update({ status: 'PAID' }).eq('id', id);
    if (error) throw error;
    return true;
  },

  // --- COMUNIDADE ---
  getPosts: async (): Promise<Post[]> => {
    if (!isConfigured()) return [];
    const { data, error } = await supabase!
      .from('posts')
      .select('*')
      .order('timestamp', { ascending: false });
    if (error) throw error;
    return data as Post[];
  },

  addPost: async (newPost: Post): Promise<Post> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('posts')
      .insert([newPost])
      .select()
      .single();
    if (error) throw error;
    return data as Post;
  },

  // --- ROTAS ---
  getRoutes: async (): Promise<Route[]> => {
    if (!isConfigured()) return [];
    const { data, error } = await supabase!.from('routes').select('*');
    if (error) throw error;
    return data as Route[];
  },

  addRoute: async (newRoute: Omit<Route, 'id'>): Promise<Route> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('routes')
      .insert([newRoute])
      .select()
      .single();
    if (error) throw error;
    return data as Route;
  },

  updateRoute: async (updatedRoute: Route): Promise<Route> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('routes')
      .update(updatedRoute)
      .eq('id', updatedRoute.id)
      .select()
      .single();
    if (error) throw error;
    return data as Route;
  },

  deleteRoute: async (id: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!.from('routes').delete().eq('id', id);
    if (error) throw error;
    return true;
  },

  // --- TREINOS PERSONALIZADOS ---
  getPersonalizedWorkouts: async (studentId?: string): Promise<PersonalizedWorkout[]> => {
    if (!isConfigured()) return [];
    let query = supabase!.from('personalized_workouts').select('*');
    const { data, error } = await query;
    if (error) throw error;
    const workouts = data as PersonalizedWorkout[];
    if (studentId) return workouts.filter(w => w.studentIds.includes(studentId));
    return workouts;
  },

  addPersonalizedWorkout: async (workout: Omit<PersonalizedWorkout, 'id'>): Promise<PersonalizedWorkout> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('personalized_workouts')
      .insert([workout])
      .select()
      .single();
    if (error) throw error;
    return data as PersonalizedWorkout;
  },

  updatePersonalizedWorkout: async (updatedWorkout: PersonalizedWorkout): Promise<PersonalizedWorkout> => {
    if (!isConfigured()) throw new Error("Supabase não configurado");
    const { data, error } = await supabase!
      .from('personalized_workouts')
      .update(updatedWorkout)
      .eq('id', updatedWorkout.id)
      .select()
      .single();
    if (error) throw error;
    return data as PersonalizedWorkout;
  },

  deletePersonalizedWorkout: async (id: string): Promise<boolean> => {
    if (!isConfigured()) return false;
    const { error } = await supabase!.from('personalized_workouts').delete().eq('id', id);
    if (error) throw error;
    return true;
  },

  // --- ESTATÍSTICAS E DASHBOARD ---
  getStudentAttendanceStats: async (studentId: string) => {
    if (!isConfigured()) return { percentage: 0, totalClasses: 0, presentCount: 0 };
    const { data } = await supabase!.from('attendance').select('present_student_ids');
    const attendedCount = data?.filter(a => a.present_student_ids.includes(studentId)).length || 0;
    const { count: totalAssigned } = await supabase!.from('classes').select('id', { count: 'exact' }).contains('enrolled_student_ids', [studentId]);
    
    const percentage = totalAssigned && totalAssigned > 0 ? Math.round((attendedCount / totalAssigned) * 100) : 100;
    return { percentage, totalClasses: totalAssigned || 0, presentCount: attendedCount };
  },

  getGlobalChallengeProgress: async () => {
    if (!isConfigured()) return { challenge: { id: 'ch1', title: 'Carregando...', targetValue: 1, unit: 'km' }, totalDistance: 0 };
    const { data: routes } = await supabase!.from('routes').select('distance_km');
    const totalDistance = routes?.reduce((acc, r) => acc + Number(r.distance_km), 0) || 0;
    return { 
      challenge: { id: 'ch1', title: 'Volta ao Mundo', targetValue: 40000, unit: 'km' }, 
      totalDistance: 12500 + totalDistance 
    };
  },

  getReportData: async (range: string) => {
    return [
        { name: 'Jan', students: 85, revenue: 12500 },
        { name: 'Fev', students: 88, revenue: 13200 },
        { name: 'Mar', students: 92, revenue: 13800 },
        { name: 'Abr', students: 95, revenue: 14250 },
    ];
  },

  getAttendanceReport: async () => {
    return [
        { name: 'Seg', attendance: 85 },
        { name: 'Ter', attendance: 78 },
        { name: 'Qua', attendance: 92 },
        { name: 'Qui', attendance: 88 },
        { name: 'Sex', attendance: 70 },
        { name: 'Sáb', attendance: 95 }
    ];
  },

  getPaymentAlerts: async () => [],
  getStudentPendingPayments: async (studentId: string) => []
};
